﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-KwXOGwxIIn6SCPI4p6DGcqFGIqY2rFTH5TtY7N+5Ruo=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-hu+wj6MZ\/ojoeLhoHEqx0vVIiOldgIrPxImczteZQjE=",
      "url": "data\/graphs\/copenhagen.json"
    },
    {
      "hash": "sha256-2oI3kQvM2rBn6QUKHsbJay1lr4K6G5S8XhLi2E\/4doE=",
      "url": "data\/graphs\/london.json"
    },
    {
      "hash": "sha256-KAz2LJhoxITb2xC2VRWVeWEOAGq8JUzN5VYg4qZgzkI=",
      "url": "data\/vehicles\/vehicles.json"
    },
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-\/2UuZUnSEO49pSpui1nAQg3sIul9Vx5RarSiWC2MnuY=",
      "url": "GoogleMapsDistanceMatrixAPI.js"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-e+wF1AI7N\/NFxB860t3YqtbhpwTY5Fx3WEkb+L0z84w=",
      "url": "icons\/delivering.png"
    },
    {
      "hash": "sha256-y6cF79SR9R0vhAsIBWqp22QexIN8MKKNFQwrvTjaDSc=",
      "url": "icons\/parked.png"
    },
    {
      "hash": "sha256-xCtc6s1MNabup2X4rdKKxmBzLnRgNEJT9yMI1AAtLrI=",
      "url": "icons\/refueling.png"
    },
    {
      "hash": "sha256-bJeSDRdvG+wqsLtyyNysFd5ziMZ1RVnjA4mwuCXOGKE=",
      "url": "icons\/returning.png"
    },
    {
      "hash": "sha256-NYLQIWQW5Z6JAneE+FcrmfjIV620gNhgNEtHdY\/JHbU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-+GjLP6\/95S6S2ZsLy0l5m7BF9nhdZtybTdECnE+brtY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-2ldEe2K8ARFKSIBsv+Hr3iNQzq9qh1H\/dwdu2r+AIyY=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-XmG1o3XoL4Dv4DjPhf+gJzrOdCMk+8d4f30sHkRIlzA=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-rip887O\/MzF0Xf3GXtIvfySYu+t66+HDS8TyLMVM1Ss=",
      "url": "_framework\/dotnet.5.0.0.js"
    },
    {
      "hash": "sha256-WeOKCkI7IdJHs2kCqsKgLfiWX4\/sNPbaRUspOLefkCY=",
      "url": "_content\/BlazorGoogleMaps\/background.png"
    },
    {
      "hash": "sha256-2wFys31AzfARvD5KdiedjFfobA6pE8XmHMJ\/643VzrU=",
      "url": "_content\/BlazorGoogleMaps\/objectManager.js"
    },
    {
      "hash": "sha256-rZf3BJ55O3pmMKt\/1ntMD1t+PPePWXxj6lQXYfCu7gI=",
      "url": "_content\/BlazorGoogleMaps\/styles.css"
    },
    {
      "hash": "sha256-PwqOb77KjGwMMMJB4dtp4ZlXP3lvnLDdRExCdEU9910=",
      "url": "_content\/BlazorLeaflet\/leafletBlazorInterops.js"
    },
    {
      "hash": "sha256-+\/IJo9wLK9sTvL8ee9W9w8S1Gkj8rsf\/6yob0uUFAaM=",
      "url": "_framework\/Blazored.LocalStorage.dll"
    },
    {
      "hash": "sha256-zb4M0BMxNjC4hlShVDKYEhKKklAuyxt8GiXzgDxqTY8=",
      "url": "_framework\/GoogleMapsComponents.dll"
    },
    {
      "hash": "sha256-hiQ5d75T78mYgpTT\/Hg0D0I0P+s62FcIovRTOVNojvg=",
      "url": "_framework\/GeoCoordinatePortable.dll"
    },
    {
      "hash": "sha256-sDaQjQZoxlAagXKIA17aW2ILW3Dj\/5du79ZBKtrIb3I=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-T7p3HirvZEra+mEXB0HSOSH8K04rz\/b5O0ojRmDIoq4=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-jyPM6R2Q988oSbJyC3MxKsUmY3R\/G3DlinczzJQX1Sg=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-bZZ69\/58+BnN9G33FpTd2iXAdfgLbBnDUiiKxfaZ7IU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-7mxFRRlriJzO95ZBz4cmDSFADogdaoDy8MxzQoNtwaU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-cwzKuqTaJjYc5QXknt6NaBt\/MWSt9DYHfmu0I\/CV2mc=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-bqAmv+2te1foBbCZP6+QwNa+Ej9GVKQRvn\/O1lINe2k=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-L3pUqB\/VjizqXBHngjeQQlblz2d7pMWYf\/y6IcwxrVg=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-SozZnCb38JE0AZkWYzjZ0ZSZx5WGRjD2xu0lZYPuoL0=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-OsmdQoFiNmpqW0WHVklQ4R5\/fLVeqFPmPBRQzZxxufQ=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-0ceIi\/iLdiKoxaztvCC\/4thA\/DazgsgrTETQXY30M3c=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-32yXMbcCMbfUq7vtlIPput8uO7SZK8E9m3V8EXMScBc=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-21OaCJJX+k6M+dYEFb5j1eJU+K+Sk6lvYDaRnsKqy8A=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-E1ZVZc8ppcbuan9B4K4NDw+BijA0pjKkIIwlnGerx9g=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-N4LS9Q4MWtwMcEiKVAm17eMYYidLKee5B788vtw\/fdY=",
      "url": "_framework\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-DlJFmOEiKlnRV6pAQEg5pxuFkKtlCRCoS9UGMk0VT9Y=",
      "url": "_framework\/OneOf.dll"
    },
    {
      "hash": "sha256-8F7bNVLQPEbMSE93yWDUEmvZ9khx8roteYnOY7yaTJo=",
      "url": "_framework\/PriorityQueue.dll"
    },
    {
      "hash": "sha256-CETD5tkXtiKEgbXyN\/lp0Ejf6LcHIhgeQIEyow2mhmY=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-eaLF0+vCNUWfDmIXMNwCRShHUyn4G7tTwu8vzw3vPyM=",
      "url": "_framework\/BlazorLeaflet.dll"
    },
    {
      "hash": "sha256-YUgSPNdkIb1WJIGzJjWjqMeDDh0Gqenozey72iMNyGA=",
      "url": "_framework\/Caelicus.dll"
    },
    {
      "hash": "sha256-1C+KXKRSbF\/gbx6tL3By7IPfx5bR9iX2If7B6R9OxfI=",
      "url": "_framework\/Microsoft.CSharp.dll"
    },
    {
      "hash": "sha256-VvAv\/SVjP9YGgkU9f3Yz+qzx9JBGgGux9scXT6WO2EE=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-H0NRRotG+86W0xlW9OELRJ+B6CWn5QPzD5wfmou5WDE=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-ocKRR1j4ZnzNzlUrPzslVbckMjcocFtCJSmF8UoQVgQ=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-IliIazyHT8NmVIapQNMup+U05IraygS0kGYI6Tx1ssM=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-NPkbSWdRIr\/BSyzfQUEqG5cnT7lvBQ3BRbQy4TnVQxY=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-HdWoEvhXl6mjwupz6WkO1qUy7sQgfMMX4ekIds+caxk=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-jrTDWL+5pK+0\/sTjLdxsgWmuEpXHaFK+A6MnEmPdFeE=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-Bg46124jm8BdPYqRZ9elCqedVW5bXvKDqI402Xn451w=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-oKyO\/6F7ULfkydeLKjmn8ttETGwhGQzY9FZjR5a3RI4=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-pOApUSscVDepAmQJzcSLcpCO\/vDysyU5e1Vz4FwU86E=",
      "url": "_framework\/System.Data.Common.dll"
    },
    {
      "hash": "sha256-KXOxkDLZoRkUMpD4HG52hX4Ka2ykzQlZ5bvJX7B3vQo=",
      "url": "_framework\/System.Diagnostics.TraceSource.dll"
    },
    {
      "hash": "sha256-6ftGdSYNtgi3T2cBoG6FIzKAY7eDQqwfs+7yIpkYszw=",
      "url": "_framework\/System.Drawing.Primitives.dll"
    },
    {
      "hash": "sha256-VBwLmAK7MPzPTcO8AYJB6rt9pY2YP6cjMl4NMrxDQbo=",
      "url": "_framework\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-Rbm9HZ1nW\/VG3hmeFYSnWDjVMhxjZnuTF3dAXGDqiVE=",
      "url": "_framework\/System.IO.FileSystem.dll"
    },
    {
      "hash": "sha256-JIwfNsvRg8vln58FVMWZ4gYKkJ07lpyHjDgYVzpp1n0=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-6mcO+\/bgVRSyDx9sD0PO\/Tyqpcqmbh8SCAZ0tcdYWFE=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-Vwn\/krmqAMwKppsJSgInJe+QHS40C9MVIwCdcoBZIKM=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-31vrsrebzMFjci2b2TZtn7Ai+eVRgkiYObgDTBZvJjc=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-OG9xSfN3Xx4hfZTU3kdRDHP0cWgdqlj2\/e7FcOgQcps=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-TUPbs4yA7l48\/YG\/fIKTu1qJhMviKk6C2ohbPIZGSQQ=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-HvOGBdR2ymsrDr3H2Gi1jKQOAxi9kCRvQgVI7PeIMLc=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-dNXhQYzBE4BJlfDRQ\/x7YofV1XIDEKe7fuHfoU8t+X0=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-fvxTtnlcCaSrhfgztAHcsUvC9hrBAC9Hq+QZUIktAXI=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-NjEtdsqTpnmK4FK+DoExKoThWIFu53cz1ubaybSDJIY=",
      "url": "_framework\/System.Private.Xml.Linq.dll"
    },
    {
      "hash": "sha256-IlHtbNkIpJ3TecS\/Yk5LgSOljVZAklPxQE9IyCJ5ZPU=",
      "url": "_framework\/System.Private.Xml.dll"
    },
    {
      "hash": "sha256-+V0hOa1yqT3xUzv2MvxfW\/Hkls6ALUO\/\/cR8gc65okE=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-WZUitHt7Lx43l9GbO+\/x1PRr\/87l96ASeAuIXeD8ccI=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-uQMMm0rob4Aheu7LdAjLi5vPqCjJG4p1LqKH+hmnPKw=",
      "url": "_framework\/System.Runtime.Numerics.dll"
    },
    {
      "hash": "sha256-eVoZzODtnhhMN5iljC8D1ysSsNnN5D82P12HewTipug=",
      "url": "_framework\/System.Runtime.Serialization.Formatters.dll"
    },
    {
      "hash": "sha256-iGDdY7rOBkxaWx25b3rJh807UQJ1gB\/QKjJvVV1qA34=",
      "url": "_framework\/System.Runtime.Serialization.Primitives.dll"
    },
    {
      "hash": "sha256-YLnB6z4pn5uxpj2\/m\/EhT3gAy5QdGx7ajLZFoWWkuSI=",
      "url": "_framework\/System.Security.Cryptography.Algorithms.dll"
    },
    {
      "hash": "sha256-p+w4VfOQe4xpDeMVUmqzR+TJIhbDwykCrATzc5\/TVUM=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-u63c97zC4Kg9GT8VDgcTmOD2eGptX7BiXNC+RIRU\/Xg=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-EiYaaZPGWN1+M7U5Dw4M5R1RzOUQ0m6hTvpYT4pX4gg=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-iTbTFAzIwcwHSd5DebcOBlyWquw3R\/n7g4nG9i4bdIQ=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-odn048zVTfldP5hw8TdG\/O43q8WLOe+mPzwKsueUKu8=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-aUUhSORllrlw6mUXuKFR72wUPfryKu60ogDqZUdBukM=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "FshyMrKL"
};
