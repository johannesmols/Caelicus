﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-WeOKCkI7IdJHs2kCqsKgLfiWX4\/sNPbaRUspOLefkCY=",
      "url": "_content\/BlazorGoogleMaps\/background.png"
    },
    {
      "hash": "sha256-2wFys31AzfARvD5KdiedjFfobA6pE8XmHMJ\/643VzrU=",
      "url": "_content\/BlazorGoogleMaps\/objectManager.js"
    },
    {
      "hash": "sha256-rZf3BJ55O3pmMKt\/1ntMD1t+PPePWXxj6lQXYfCu7gI=",
      "url": "_content\/BlazorGoogleMaps\/styles.css"
    },
    {
      "hash": "sha256-KwXOGwxIIn6SCPI4p6DGcqFGIqY2rFTH5TtY7N+5Ruo=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-cNn54fwrRp0s2rurlzBj44QJ7u7JciWNkAqYQZ4iTAI=",
      "url": "data\/graphs\/copenhagen.json"
    },
    {
      "hash": "sha256-qqMWpmr5mgwS2RD8gJgQGxfu6buUlF6T7IH2YkzcA4s=",
      "url": "data\/graphs\/london.json"
    },
    {
      "hash": "sha256-5booBZbhnImcvBF7UMNt1nwiVlDI51YOJLJI3ZVPaJs=",
      "url": "data\/vehicles\/vehicles.json"
    },
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-l4TOYJUjCMhNzLaOMXd2\/qHaxJCynSB11r+JZNwRPs0=",
      "url": "icons\/circle_green.svg"
    },
    {
      "hash": "sha256-tKhpLNSkQ\/2nuVGNTV9Xb8zy7GFL7MjqPoLuXRw2WvY=",
      "url": "icons\/home_black.svg"
    },
    {
      "hash": "sha256-Pz\/ICKyZsya9Somednx0CmGcj4b\/Ol4vOE6mWXBrYFQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-+GjLP6\/95S6S2ZsLy0l5m7BF9nhdZtybTdECnE+brtY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-YP58Sa5yi8xHtj2tYZwV1fQmVByrIczuDc2zrYwLv5I=",
      "url": "_framework\/_bin\/Blazored.LocalStorage.dll"
    },
    {
      "hash": "sha256-kp4ZQxYfjyIm76Ng0jEKF62961HtqeGihhnN9nG1LGY=",
      "url": "_framework\/_bin\/Caelicus.dll"
    },
    {
      "hash": "sha256-vsw1mntpZOK7QizzaE2s97mNuGjgSE55WLz2IwARZow=",
      "url": "_framework\/_bin\/GeoCoordinatePortable.dll"
    },
    {
      "hash": "sha256-I4KlC9mXbu06ajJ7II9nulbuUexzjfGjMZ9v5eN07ps=",
      "url": "_framework\/_bin\/GoogleMapsComponents.dll"
    },
    {
      "hash": "sha256-T9LG3ay3HGRFp2hNvcwJYfxy6X5KmY8rlkKfC+v\/kFQ=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-rmvrLieely7JLi1+DcQ4wQNGHslE8KUjl23OOnpk0io=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-jBNMX4q0gpC2SJBjRQrnTBOAKN3wE\/8sbw0XwccO\/HI=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-jzHgXWAvWMkKIGFjZoT84tbe72E+H7CvTr\/Dryh4QPs=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-+d5MVwK4dPMjOFWS\/A0G1Ypre2lM1xWx6jP9u9L+gGg=",
      "url": "_framework\/_bin\/Microsoft.CSharp.dll"
    },
    {
      "hash": "sha256-yOQwq8M\/15wF4Z27F2L983UotZBwaTmRhG23B07yJxE=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-DQQp2JmK2VeZuRXLKI71CNFDgxdxBMp2yJKOoaoO1Wk=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-C8RhBUe8E4y66EJF4a\/8BJHnXIWCUwlZiazCEIfVqlk=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-STSHUK6lNI6CNOVL0NHOrFLPvoRDVNSV3uJMp0RL9ZM=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-VnH1d3ge901k7tvcG+j0YrBaxhC\/n3bLaUkyKo4JQ84=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-5\/lhfh7cWDZi9bY3C8M20RZ2MBOWLCCCwHRaERG\/u1s=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-lce1LX9UzjIB7cODAxDZrlQfYXwc2lp6qQJPGsflVMc=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-I2qNtDmI0B0mJAK7jt6oU1sFtkOczIrRSpxvBeT2MaU=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-isWaOU9ZUJPQDLeejW2uB0pjzCTzRLb8DyxV\/wMHd3I=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-3cbvJEo8k8VJVQwyEZWWQ6yGRFQW8\/219DaOnmsX3e4=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-zV\/OfJNfNsG404X30Pwkdymdh1KmZpTVEmG\/JNFVc\/k=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-xtYjSnxSJDwWZ2j0UZZrF3PVaIUT5bPSNYs3jyZcLOo=",
      "url": "_framework\/_bin\/Mono.Security.dll"
    },
    {
      "hash": "sha256-PEHLaPExgunT9rmZmgrjYzBItpnOIkSga4fyZ7s9lt0=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-8+aWlQshkso8ei8xp5J0gn4ZNGRYRMqXzI+osKzgVYI=",
      "url": "_framework\/_bin\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-JQ6lHtdX+tyw8S+gQJlA23Xq0UgnlU6iXH7NhUa4t8U=",
      "url": "_framework\/_bin\/OneOf.dll"
    },
    {
      "hash": "sha256-V6iagRZZOdMuIpB0caqxY3wxbrl0Sn7X+Xyg5T8Jm2E=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-uV1rwygom53i8omZOgROAQ+HE3kB1kWXm5qlePkHahs=",
      "url": "_framework\/_bin\/System.Data.dll"
    },
    {
      "hash": "sha256-+38IoE6z1hLbchiLS2ujr493+RdPoTprXX4FbFU0Hi0=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-Kwt2gWCzdksurB\/8alzdvACBSKVSXcF3XXe2Pjbbfs8=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-6pj+C\/+Oi+4EFKjg2MYvQYiFLv3I0vcodFl1TkrhAkI=",
      "url": "_framework\/_bin\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-QN+4YN2U0Ol8RNEoTaUCFIrfmQ6JI04uEuVQTNGR6JQ=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-MJgHhafb68LqLpsdjhkM5OWqbKyLjx8UUqhurEfXwps=",
      "url": "_framework\/_bin\/System.Numerics.dll"
    },
    {
      "hash": "sha256-PZkXepzlFdJEQE1GFbJC34K0sySqgQtBIG33Mcp7Krg=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-iu2o5Zy8tg+kQt8ONqjPfPwBljlUbnmpUvSa7sjTwWE=",
      "url": "_framework\/_bin\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-ssI5TnI6D0lQBBWURy\/qN+xIGMuGHjTcL4oCuM93e\/U=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-+oFCbKNKQa0rDe+z0OZ6L07MIJ9FGcaHVNjpzeK\/0\/U=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-p\/B3jje71e4BA7Cn98Rav3cZAzqBBSC2EH2idZque8I=",
      "url": "_framework\/_bin\/System.Xml.dll"
    },
    {
      "hash": "sha256-FwER+iUYMdEcsSPeMXMTXb+RPN8FBcHdV1gGpDbynkE=",
      "url": "_framework\/_bin\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-ZNklpbg6XKU312i2wkuNkWyUHdT1WujOhoRyHEkrjw8=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-HqzGtQBpZgrvKaDdMqSTE1KSYzm1JPRIiIu9mdFkljM=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "N1g53ea7"
};
