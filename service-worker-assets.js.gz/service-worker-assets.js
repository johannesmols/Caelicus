﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-WeOKCkI7IdJHs2kCqsKgLfiWX4\/sNPbaRUspOLefkCY=",
      "url": "_content\/BlazorGoogleMaps\/background.png"
    },
    {
      "hash": "sha256-2wFys31AzfARvD5KdiedjFfobA6pE8XmHMJ\/643VzrU=",
      "url": "_content\/BlazorGoogleMaps\/objectManager.js"
    },
    {
      "hash": "sha256-rZf3BJ55O3pmMKt\/1ntMD1t+PPePWXxj6lQXYfCu7gI=",
      "url": "_content\/BlazorGoogleMaps\/styles.css"
    },
    {
      "hash": "sha256-KwXOGwxIIn6SCPI4p6DGcqFGIqY2rFTH5TtY7N+5Ruo=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-xuGPDnFYoYovSNFt3zl2UJzbI2q3ybnjzzjdWShlj9c=",
      "url": "data\/graphs\/copenhagen.json"
    },
    {
      "hash": "sha256-2oI3kQvM2rBn6QUKHsbJay1lr4K6G5S8XhLi2E\/4doE=",
      "url": "data\/graphs\/london.json"
    },
    {
      "hash": "sha256-ePcHkGf7HXXYpO324jYWFOGWUgS2sOoKjbDMAZDtsX0=",
      "url": "data\/vehicles\/vehicles.json"
    },
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-l4TOYJUjCMhNzLaOMXd2\/qHaxJCynSB11r+JZNwRPs0=",
      "url": "icons\/circle_green.svg"
    },
    {
      "hash": "sha256-tKhpLNSkQ\/2nuVGNTV9Xb8zy7GFL7MjqPoLuXRw2WvY=",
      "url": "icons\/home_black.svg"
    },
    {
      "hash": "sha256-Pz\/ICKyZsya9Somednx0CmGcj4b\/Ol4vOE6mWXBrYFQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-+GjLP6\/95S6S2ZsLy0l5m7BF9nhdZtybTdECnE+brtY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-YP58Sa5yi8xHtj2tYZwV1fQmVByrIczuDc2zrYwLv5I=",
      "url": "_framework\/_bin\/Blazored.LocalStorage.dll"
    },
    {
      "hash": "sha256-hD\/65JGaS5oi4OCJ\/bHE+Ud6KGksrXz5k6LTBGlsqrY=",
      "url": "_framework\/_bin\/Caelicus.dll"
    },
    {
      "hash": "sha256-vsw1mntpZOK7QizzaE2s97mNuGjgSE55WLz2IwARZow=",
      "url": "_framework\/_bin\/GeoCoordinatePortable.dll"
    },
    {
      "hash": "sha256-I4KlC9mXbu06ajJ7II9nulbuUexzjfGjMZ9v5eN07ps=",
      "url": "_framework\/_bin\/GoogleMapsComponents.dll"
    },
    {
      "hash": "sha256-9dNAbDAkAbCs+t6nNHi9XWP5lrdU1AombnxVTvjjn0A=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-baPbIhS3d5+1GuzKgpkdFBpP9RRiNiND61yNdHgLD60=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-vdpZBjdxEdgWED15KhnLNLGvRHrv0HNwjRDI9OoeEV0=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-jzHgXWAvWMkKIGFjZoT84tbe72E+H7CvTr\/Dryh4QPs=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-+d5MVwK4dPMjOFWS\/A0G1Ypre2lM1xWx6jP9u9L+gGg=",
      "url": "_framework\/_bin\/Microsoft.CSharp.dll"
    },
    {
      "hash": "sha256-6YwY1Jr96kZXGzWyheGAdvrtXI+rJlKMav6YQnJqPy8=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-QfHkXwvgNBpbb1esbwQXRhxF0uX4pmseYJ\/Qcm1ig5Q=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-7x1OhJY+2PuQd2YXjXNHLfLRfp+ajFOihk+h6K3hwLE=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-EVOafteFivszXH2CO84SnK3RYADYThywUtldYzl8KPo=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-lb6006rUXij7tsQyrxnxwwOpoFJt\/iuBfomLtAIOUuU=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-aPVBQmoHce2bDtm+6TFwgfbIPr8MPhY6Yo7PQRU35jY=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-Yij03elN\/oU45puVMRCFzl4kIWTzEjqJF63LCno71Vg=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-Bz9zUVp39yqSJ4WrkfWPQmYTWr31tdrMKn1huxhlYzk=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-EIyyJtPJUJ9CeTgSVNuZmYPf1+JQRTEA6+lDcUBcIp4=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-3cbvJEo8k8VJVQwyEZWWQ6yGRFQW8\/219DaOnmsX3e4=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-zV\/OfJNfNsG404X30Pwkdymdh1KmZpTVEmG\/JNFVc\/k=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-d7Okfus30vEJ1+FEgJYPd88vhJmTVU\/DZPAfa4JbfYo=",
      "url": "_framework\/_bin\/Mono.Security.dll"
    },
    {
      "hash": "sha256-6npKOKuD9ZWJq+ZoRUEoPqFZKSsVwvojkYgU6joqPyA=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-8+aWlQshkso8ei8xp5J0gn4ZNGRYRMqXzI+osKzgVYI=",
      "url": "_framework\/_bin\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-JQ6lHtdX+tyw8S+gQJlA23Xq0UgnlU6iXH7NhUa4t8U=",
      "url": "_framework\/_bin\/OneOf.dll"
    },
    {
      "hash": "sha256-\/abdLhFpOWmr7GczlV2rWq6QfMypDANFghWD4nIONfc=",
      "url": "_framework\/_bin\/PriorityQueue.dll"
    },
    {
      "hash": "sha256-npIvd4WossFZCCoRd\/6FGJ5Np5xoj1ek\/rcbT3BYwvM=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-p6xXExGnZvfp14Tt55OkflqPNWmedxtph9lsuJYfrmI=",
      "url": "_framework\/_bin\/System.Data.dll"
    },
    {
      "hash": "sha256-qnjmnsIaOWfuAD47hv\/yF4l5ZAd38resXDkTQejhPT4=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-8sxNu7xXxDoZULajVAfnDUJBVz1O\/0lHT0pllLepFh4=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-2KcGUWOUc4dbf6zuiwBHsqTBpIs8KpuHhFtr2m8\/b4s=",
      "url": "_framework\/_bin\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-t8c+GUh9+hkHSJPcECW\/vlPXXwsqmxbOz\/Utx7drZMA=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-U6y6TRpaLfBRzSd+YiYJyc1CUchKq34NqF2Vm7grvEI=",
      "url": "_framework\/_bin\/System.Numerics.dll"
    },
    {
      "hash": "sha256-1DD3zBvnK08SQgNzNLzqId7ZYvjvo\/YxYwMlRBX2yk4=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-4ZVjKeysf5IcSQ4vPAd33USVBzca6m3Ktfy05mWoai0=",
      "url": "_framework\/_bin\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-zBOA6nklsw3QtJZ6okapE879m43Hww5gITlwKG2N8uI=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-5wNxIhDcU\/ojL7LZxtkPMjNGN1rRNpeZhSRO9unXXvg=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-q4S7PTrU5vtTvaz5JlUMLwZIPN9h8VfbgzIojt4oj\/g=",
      "url": "_framework\/_bin\/System.Xml.dll"
    },
    {
      "hash": "sha256-sb2UfkFzkU9jHs9\/b1L9aFHY+cRaSNfaYMerv990iv8=",
      "url": "_framework\/_bin\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-qTX\/t9rmdx+ua3O6\/z+tUGgD9Cnh7QWIcXRshMH+glw=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gsxuo81gdZRGlzsTE1O5oJEw0Taa\/V3RxRyYtg2nDcw=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "Jz5RKrPd"
};
